package p3;

public class MessageBeanKr implements MessageBean{
	public void sayHello(String name){
		System.out.println("�ȳ��ϼ���. " + name);
		
	}
}
